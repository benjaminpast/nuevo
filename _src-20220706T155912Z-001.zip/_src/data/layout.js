module.exports = 'lesson.njk'
